# 🐒 Amaury Ouistiti

Éditeur de texte universel avec 26 formats d'export, OCR (reconnaissance de texte par photo), traducteur dans 30+ langues et correcteur orthographe/grammaire.

## 📦 Contenu de ce paquet

```
.
├── amaury-ouistiti-source.zip        ← Le code source compressé (à uploader)
├── .github/
│   └── workflows/
│       └── build-apk.yml             ← Le workflow GitHub Actions
└── README.md                         ← Ce fichier
```

Le ZIP `amaury-ouistiti-source.zip` contient :

```
amaury-ouistiti-source/
├── www/
│   ├── index.html                    ← L'application complète
│   ├── manifest.json                 ← Manifest PWA
│   ├── icon-192.png
│   └── icon-512.png
├── resources/
│   ├── icon.png                      ← Icône source (1024x1024)
│   └── splash.png                    ← Écran de démarrage
├── capacitor.config.json             ← Configuration Capacitor
├── package.json                      ← Dépendances Node.js
└── .gitignore
```

## 🚀 Comment construire l'APK sur GitHub

### Étape 1 — Créer un dépôt GitHub

1. Allez sur [github.com/new](https://github.com/new)
2. Donnez un nom à votre dépôt (par exemple `amaury-ouistiti`)
3. Laissez-le **public** ou **privé** selon votre préférence
4. **Ne cochez pas** « Initialize with README »
5. Cliquez sur **Create repository**

### Étape 2 — Uploader les fichiers

Méthode la plus simple via l'interface web :

1. Sur la page d'accueil de votre nouveau dépôt, cliquez sur **uploading an existing file**
2. Glissez-déposez (ou cliquez pour sélectionner) :
   - Le fichier **`amaury-ouistiti-source.zip`**
   - Le fichier **`README.md`** *(optionnel)*
3. Pour le workflow, vous devez recréer la structure de dossiers. Cliquez sur **Add file → Create new file** et tapez :
   ```
   .github/workflows/build-apk.yml
   ```
   Puis collez tout le contenu du fichier `build-apk.yml`.
4. Cliquez sur **Commit changes** en bas de la page.

### Étape 3 — Lancer la construction de l'APK

Le workflow se lance **automatiquement** dès que vous avez uploadé les fichiers. Vous pouvez aussi :

1. Aller dans l'onglet **Actions** de votre dépôt
2. Sélectionner le workflow **🐒 Construire l'APK Amaury Ouistiti**
3. Cliquer sur **Run workflow** puis **Run workflow** (à droite)

La construction prend environ **5 à 10 minutes** la première fois.

### Étape 4 — Récupérer l'APK

Une fois la construction réussie (icône verte ✓) :

**Option A — Depuis les artefacts**
1. Cliquez sur le nom de la construction terminée dans l'onglet **Actions**
2. En bas de la page, dans la section **Artifacts**, téléchargez `amaury-ouistiti-apk`
3. Décompressez l'archive téléchargée pour obtenir `amaury-ouistiti.apk`

**Option B — Depuis les Releases (créées automatiquement)**
1. Allez dans l'onglet **Releases** (à droite de la page du dépôt)
2. Téléchargez directement `amaury-ouistiti.apk` depuis la dernière release

### Étape 5 — Installer sur Android

1. Transférez le fichier `amaury-ouistiti.apk` sur votre téléphone (par USB, email, Drive…)
2. Ouvrez le fichier depuis votre gestionnaire de fichiers
3. Si Android prévient « Source inconnue », autorisez l'installation pour cette fois
4. Appuyez sur **Installer**
5. Lancez **Amaury Ouistiti** depuis votre menu d'applications 🐒

## 🛠️ Construire localement (optionnel)

Si vous voulez construire l'APK sur votre propre machine au lieu de GitHub :

### Prérequis

- [Node.js 18+](https://nodejs.org/)
- [JDK 17](https://adoptium.net/)
- [Android Studio](https://developer.android.com/studio) (pour le SDK Android)

### Étapes

```bash
# Décompresser le source
unzip amaury-ouistiti-source.zip
cd amaury-ouistiti-source

# Installer les dépendances
npm install

# Ajouter la plateforme Android (à faire une seule fois)
npx cap add android

# Synchroniser les fichiers web
npx cap sync android

# Construire l'APK
cd android
./gradlew assembleDebug

# L'APK se trouve dans :
# android/app/build/outputs/apk/debug/app-debug.apk
```

## 📱 Tester sans construire d'APK

L'application étant 100 % web, vous pouvez aussi :

- **Ouvrir `www/index.html` dans n'importe quel navigateur**
- L'**installer comme PWA** depuis Chrome/Edge : menu > « Installer Amaury Ouistiti »

## 🔧 Personnalisation

| Fichier | Pour modifier… |
|---|---|
| `www/index.html` | L'éditeur lui-même (interface, fonctions) |
| `capacitor.config.json` | Le nom de l'application, l'identifiant Android |
| `resources/icon.png` | L'icône de l'application |
| `resources/splash.png` | L'écran de démarrage |

Pour changer le nom affiché, modifiez `appName` dans `capacitor.config.json`.

## 📜 Licence

MIT — Vous pouvez utiliser, modifier et partager librement.

---

Fait avec ❤️ pour qu'écrire reste un plaisir.
